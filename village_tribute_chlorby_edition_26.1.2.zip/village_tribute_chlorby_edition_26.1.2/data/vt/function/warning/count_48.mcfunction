execute as @e[type=minecraft:villager,distance=..48] run scoreboard players add @a[tag=vt_warning_subject,limit=1] vt_temp 1
